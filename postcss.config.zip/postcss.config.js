export default {
   plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
};
